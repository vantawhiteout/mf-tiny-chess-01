t=print
s=enumerate
S=False
R=len
k=bytearray
N=int
a=None
F=True
H=abs
E=range
import json as T,os,random as u,sys as I,urllib.error,urllib.request
U='abcdefgh'
Q=tuple(A for A in E(128)if not A&136)
B,G=0,1
v=30000
V=1<<30
b=(),(16,32,15,17),(33,31,18,14,-33,-31,-18,-14),(17,15,-17,-15),(16,1,-16,-1),(17,15,-17,-15,16,1,-16,-1),(17,15,-17,-15,16,1,-16,-1)
w=33,31,18,14,-33,-31,-18,-14
c=17,15,-17,-15
d=16,1,-16,-1
J=[15]*128
for(x,y)in((4,3),(0,2),(7,1),(116,12),(112,8),(119,4)):J[x]&=15^y
def l(sq):return U[sq&7]+str((sq>>4)+1)
def L(name):return(N(name[1])-1)*16+U.index(name[0])
def z(fen):
	A=fen.split();D=k(128)
	for(J,K)in s(A[0].split('/')):
		E=0
		for C in K:
			if C.isdigit():E+=N(C)
			else:D[(7-J)*16+E]='.PNBRQKpnbrqk'.index(C);E+=1
	H=G if A[1]=='b'else B;F=0
	for C in A[2]:F|={'K':1,'Q':2,'k':4,'q':8}.get(C,0)
	I=L(A[3])if R(A)>3 and A[3]!='-'else-1;M=N(A[4])if R(A)>4 else 0;return D,H,F,I,M,A1(D,H,F,I)
m=82,337,365,477,1025,0
n=94,281,297,512,936,0
A0=0,1,1,2,4,0
A=u.Random(12648430)
C=[[A.getrandbits(64)for B in E(128)]for B in E(13)]
e=A.getrandbits(64)
M=[A.getrandbits(64)for B in E(16)]
W=[A.getrandbits(64)for B in E(9)]
def A1(board,side,cast,ep):
	A=e if side else 0;A^=M[cast]
	if ep>=0:A^=W[ep&7]
	for B in Q:
		D=board[B]
		if D:A^=C[D][B]
	return A
def D(board,sq,by):
	E=board;A=by;G,H=sq&7,sq>>4;L=H-1 if A==B else H+1;P=1 if A==B else 7
	if 0<=L<8:
		for M in(G-1,G+1):
			if 0<=M<8 and E[L*16+M]==P:return F
	Q=2 if A==B else 8
	for(I,J)in((-2,-1),(-2,1),(-1,-2),(-1,2),(1,-2),(1,2),(2,-1),(2,1)):
		C,D=G+I,H+J
		if 0<=C<8 and 0<=D<8 and E[D*16+C]==Q:return F
	R=6 if A==B else 12
	for I in(-1,0,1):
		for J in(-1,0,1):
			if I or J:
				C,D=G+I,H+J
				if 0<=C<8 and 0<=D<8 and E[D*16+C]==R:return F
	T=(3,5)if A==B else(9,11);U=(4,5)if A==B else(10,11)
	for(V,W)in((c,T),(d,U)):
		for N in V:
			K=sq+N
			while not K&136:
				O=E[K]
				if O:
					if O in W:return F
					break
				K+=N
	return S
def O(board,side):return board.index(6 if side==B else 12)
def A2(board,side,cast,ep):
	W='qrbn';M=cast;I=side;A=board;F=[];N=1-I
	for C in Q:
		J=A[C]
		if not J or(J<7)!=(I==B):continue
		K=J if J<7 else J-6;Z,P=C&7,C>>4
		if K==1:
			O=16 if I==B else-16;T=6 if I==B else 1;U=C+O
			if not A[U]:
				R=W if P==T else(0,)
				for S in R:F.append((C,U,S))
				V=C+2*O;X=1 if I==B else 6
				if P==X and not A[V]:F.append((C,V,0))
			for H in(O-1,O+1):
				L=C+H
				if L&136:continue
				if A[L]and(A[L]<7)==(N==B)or L==ep:
					R=W if P==T else(0,)
					for S in R:F.append((C,L,S))
		elif K==2:
			for H in w:
				E=C+H
				if not E&136 and(not A[E]or(A[E]<7)==(N==B)):F.append((C,E,0))
		elif K in(3,4,5):
			Y=c if K==3 else d if K==4 else b[5]
			for H in Y:
				E=C+H
				while not E&136:
					if not A[E]:F.append((C,E,0))
					else:
						if(A[E]<7)==(N==B):F.append((C,E,0))
						break
					E+=H
		else:
			for H in b[6]:
				E=C+H
				if not E&136 and(not A[E]or(A[E]<7)==(N==B)):F.append((C,E,0))
			if I==B and C==4:
				if M&1 and A[7]==4 and not A[5]and not A[6]and not D(A,4,G)and not D(A,5,G)and not D(A,6,G):F.append((4,6,0))
				if M&2 and A[0]==4 and not A[1]and not A[2]and not A[3]and not D(A,4,G)and not D(A,3,G)and not D(A,2,G):F.append((4,2,0))
			elif I==G and C==116:
				if M&4 and A[119]==10 and not A[117]and not A[118]and not D(A,116,B)and not D(A,117,B)and not D(A,118,B):F.append((116,118,0))
				if M&8 and A[112]==10 and not A[113]and not A[114]and not A[115]and not D(A,116,B)and not D(A,115,B)and not D(A,114,B):F.append((116,114,0))
	return[B for B in F if A[B[1]]not in(6,12)]
def A3(board,ksq,f,side):
	A=(f&7)-(ksq&7);C=(f>>4)-(ksq>>4)
	if not(A or C)or A and C and H(A)!=H(C):return S
	F=(A>0)-(A<0)+16*((C>0)-(C<0));G=(3,5,9,11)if A and C else(4,5,10,11);D=f+F
	while not D&136:
		E=board[D]
		if E:return(E<7)!=(side==B)and E in G
		D+=F
	return S
def f(board,side,cast,ep):
	B=side;A=board;C=O(A,B);J=D(A,C,1-B);G=[]
	for E in A2(A,B,cast,ep):
		F,H,K=E
		if J or F==C or A3(A,C,F,B)or A[F]in(1,7)and H==ep and not A[H]:
			I=X(A,B,cast,ep,0,0,E)[0]
			if D(I,O(I,B),1-B):continue
		G.append(E)
	return G
def X(board,side,cast,ep,half,key,mv):
	I=board;D,B,N=mv;F=I[D];A=k(I);E=key^C[F][D];G=I[B]
	if G:E^=C[G][B]
	A[D]=0
	if N:P='.PNBRQK'.index(N.upper())+(6 if side else 0);A[B]=P
	else:A[B]=F
	E^=C[A[B]][B]
	if F in(1,7)and B==ep and not G and D&7!=B&7:K=B-16 if F==1 else B+16;G=A[K];A[K]=0;E^=C[G][K]
	if F==6 and D==4 and B==6:A[5],A[7]=A[7],0;E^=C[4][7]^C[4][5]
	elif F==6 and D==4 and B==2:A[3],A[0]=A[0],0;E^=C[4][0]^C[4][3]
	elif F==12 and D==116 and B==118:A[117],A[119]=A[119],0;E^=C[10][119]^C[10][117]
	elif F==12 and D==116 and B==114:A[115],A[112]=A[112],0;E^=C[10][112]^C[10][115]
	O=cast&J[D]&J[B];L=(D+B)//2 if F in(1,7)and H(B-D)==32 else-1;Q=0 if G or F in(1,7)else half+1;E^=e^M[cast]^M[O]
	if ep>=0:E^=W[ep&7]
	if L>=0:E^=W[L&7]
	return A,1-side,O,L,Q,E
def g(board,side):
	I=J=K=M=0
	for L in Q:
		D=board[L]
		if not D:continue
		C=D if D<7 else D-6;O=L&7;E=L>>4 if D<7 else 7-(L>>4);A=7-H(2*O-7)-H(2*E-7);K+=A0[C-1]
		if C==1:F,G=4*A+E*E//2,8*A+10*E
		elif C==2:F,G=9*A,6*A
		elif C==3:F,G=5*A,5*A
		elif C==4:F,G=3*A+5*E,4*A
		elif C==5:F,G=2*A,3*A
		else:F,G=-7*A-3*(7-E),9*A+4*E
		if D<7:I+=m[C-1]+F;J+=n[C-1]+G
		else:I-=m[C-1]+F;J-=n[C-1]+G
		if C==3:M+=1 if D<7 else-1
	if M>=2:I+=30;J+=45
	elif M<=-2:I-=30;J-=45
	if K>24:K=24
	N=(I*K+J*(24-K))//24;return N+12 if side==B else-N+12
o=100000
h=40
Y={}
Z=[[0,0]for A in E(h+8)]
i={}
K=0
class j(Exception):0
def p(mv,ttmove,board,ply):
	B=board;A=mv
	if A==ttmove:return 1<<28
	C=B[A[1]]
	if C or B[A[0]]in(1,7)and A[2]:D=B[A[0]];E=(C or 1)*16-D;return 1<<20+E
	if A==Z[ply][0]:return 1<<19
	if A==Z[ply][1]:return 1<<18
	return i.get((B[A[0]],A[1]),0)
def q(board,side,cast,ep,half,key,alpha,beta,ply,qd):
	J=beta;I=cast;E=alpha;C=side;A=board;global K;K+=1
	if K>o:raise j
	N=O(A,C);P=D(A,N,1-C)
	if not P:
		G=g(A,C)
		if G>=J:return G
		if G>E:E=G
		if qd<=0:return E
		M=[B for B in f(A,C,I,ep)if A[B[1]]or B[2]or A[B[0]]in(1,7)and B[1]==ep and B[0]&7!=B[1]&7]
	else:
		if qd<=-4:return g(A,C)
		M=f(A,C,I,ep)
	L=[]
	for F in M:B=X(A,C,I,ep,half,key,F);Q=A[F[1]]or(1 if F[2]else 0);L.append((Q*16-A[F[0]],F,B))
	L.sort(key=lambda c:-c[0])
	for(R,F,B)in L:
		H=-q(B[0],B[1],B[2],B[3],B[4],B[5],-J,-E,ply+1,qd-1)
		if H>=J:return H
		if H>E:E=H
	return E
def P(board,side,cast,ep,half,key,depth,alpha,beta,ply,path):
	c=half;b=cast;Q=ep;M=path;L=key;J=side;I=board;G=ply;F=beta;E=alpha;B=depth;global K;K+=1
	if K>o:raise j
	if c>=100 or L in M:return 0
	if G>=h:return g(I,J)
	if B<=0:return q(I,J,b,Q,c,L,E,F,G,6)
	d=D(I,O(I,J),1-J)
	if d:B+=1
	R=Y.get(L);w=R[3]if R else a
	if R and R[0]>=B and G:
		A2,S,T,x=R
		if T==0:return S
		if T==1 and S>=F:return S
		if T==2 and S<=E:return S
	if not d and B>=3:
		y=k(I);n=L^e
		if Q>=0:n^=W[Q&7]
		z=2+(B>6);H=-P(y,1-J,b,-1,c+1,n,B-z-1,-F,-F+1,G+1,M)
		if H>=F:return H
	U=[]
	for C in f(I,J,b,Q):U.append((p(C,w,I,G),C,X(I,J,b,Q,c,L,C)))
	if not U:return-v+G if d else 0
	U.sort(key=lambda c:-c[0]);N=-V;r=U[0][1];A0=E;M.add(L)
	for(l,(x,C,A))in s(U):
		A1=D(A[0],O(A[0],1-J),J);m=0
		if l>=4 and B>=3 and not d and not A1 and not A[0][C[1]]and not C[2]:m=1+(l>=10 and B>=5)
		if l==0:H=-P(A[0],A[1],A[2],A[3],A[4],A[5],B-1,-F,-E,G+1,M)
		else:
			H=-P(A[0],A[1],A[2],A[3],A[4],A[5],max(0,B-1-m),-E-1,-E,G+1,M)
			if H>E and(m or H<F):H=-P(A[0],A[1],A[2],A[3],A[4],A[5],B-1,-F,-E,G+1,M)
		if H>N:N=H;r=C
		if H>E:E=H
		if E>=F:
			if not A[0][C[1]]and not C[2]:
				t=Z[G]
				if t[0]!=C:Z[G]=[C,t[0]]
				u=I[C[0]],C[1];i[u]=i.get(u,0)+B*B
			break
	M.discard(L);T=0 if N>A0 and N<F else 1 if N>=F else 2;Y[L]=B,N,T,r;return N
def A4(fen,legal):
	N=legal;global K,Y;H,T,U,W,Z,O=z(fen);D=set()
	for A in N:
		F,C=L(A[:2]),L(A[2:4])
		if F&136 or C&136 or H[C]in(6,12):continue
		D.add((F,C,A[4]if R(A)==5 else 0))
	if not D:return N[0]
	b=next(iter(sorted(D)));Q=b;Y={};K=0
	try:
		for c in E(1,h+1):
			I=a;S=-V;J,d=-V,V;e={O};M=[]
			for A in D:B=X(H,T,U,W,Z,O,A);M.append((A,B))
			M.sort(key=lambda c:-p(c[0],a,H,0))
			for(A,B)in M:
				G=-P(B[0],B[1],B[2],B[3],B[4],B[5],c-1,-d,-J,1,set(e))
				if G>S:S,I=G,A
				if G>J:J=G
			if I is not a:Q=I
	except j:0
	F,C,f=Q;return l(F)+l(C)+(f or'')
def r(path,body,url):
	A=urllib.request.Request(url+path,data=T.dumps(body).encode('utf-8'),headers={'content-type':'application/json'})
	try:
		with urllib.request.urlopen(A)as B:return T.load(B)
	except urllib.error.HTTPError as C:I.exit('%s: HTTP %d'%(path,C.code))
def A5():
	G='game';E='done';D='status';B=os.environ.get('MAKEFUN_ENV_URL')
	if not B:I.exit('MAKEFUN_ENV_URL is not set')
	while F:
		A=r('/game',{},B)
		if A[D]==E:break
		C=A[G]
		while A[D]=='your_move':H=A4(A['fen'],A['legal_moves']);A=r('/move',{G:C,'move':H},B)
		t('game %d: %s'%(C,A.get('outcome')),file=I.stderr)
	t(E,file=I.stderr)
if __name__=='__main__':A5()
